#!/usr/bin/env bash
set -euo pipefail

ROOT="efras-toko"
mkdir -p "$ROOT"
mkdir -p "$ROOT/prisma"
mkdir -p "$ROOT/pages/api"
mkdir -p "$ROOT/pages/products"
mkdir -p "$ROOT/lib"
mkdir -p "$ROOT/styles"
mkdir -p "$ROOT/.github/workflows"

cat > "$ROOT/README.md" <<'EOF'
# efras-toko

Efras Toko - storefront skeleton built with Next.js, Tailwind CSS, Prisma (PostgreSQL), Stripe, and NextAuth.

Features:
- Product catalog and product pages
- Cart and checkout (Stripe placeholder)
- User authentication (NextAuth placeholder)
- Admin dashboard scaffold (CRUD via API)
- Prisma schema + seed script

Quick start
1. Copy .env.example to .env and fill values (DATABASE_URL, NEXTAUTH_SECRET, STRIPE_SECRET_KEY)
2. npm install
3. npx prisma migrate dev --name init
4. npm run seed
5. npm run dev
EOF

cat > "$ROOT/package.json" <<'EOF'
{
  "name": "efras-toko",
  "version": "0.1.0",
  "private": true,
  "scripts": {
    "dev": "next dev",
    "build": "next build",
    "start": "next start",
    "lint": "next lint",
    "seed": "ts-node --transpile-only prisma/seed.ts"
  },
  "dependencies": {
    "next": "13.4.10",
    "react": "18.2.0",
    "react-dom": "18.2.0",
    "prisma": "5.5.0",
    "@prisma/client": "5.5.0",
    "tailwindcss": "3.4.0",
    "autoprefixer": "10.4.0",
    "postcss": "8.4.0",
    "stripe": "11.12.0",
    "next-auth": "4.22.1"
  },
  "devDependencies": {
    "typescript": "5.1.3",
    "ts-node": "10.9.1",
    "eslint": "8.44.0",
    "eslint-config-next": "13.4.10"
  }
}
EOF

cat > "$ROOT/next.config.js" <<'EOF'
module.exports = {
  reactStrictMode: true,
}
EOF

cat > "$ROOT/tsconfig.json" <<'EOF'
{
  "compilerOptions": {
    "target": "es2020",
    "lib": ["dom", "dom.iterable", "esnext"],
    "allowJs": true,
    "skipLibCheck": true,
    "strict": true,
    "forceConsistentCasingInFileNames": true,
    "noEmit": true,
    "esModuleInterop": true,
    "module": "esnext",
    "moduleResolution": "node",
    "resolveJsonModule": true,
    "isolatedModules": true,
    "jsx": "preserve"
  },
  "include": ["next-env.d.ts", "**/*.ts", "**/*.tsx"],
  "exclude": ["node_modules"]
}
EOF

cat > "$ROOT/postcss.config.js" <<'EOF'
module.exports = {
  plugins: {
    tailwindcss: {},
    autoprefixer: {},
  },
}
EOF

cat > "$ROOT/tailwind.config.js" <<'EOF'
module.exports = {
  content: ["./pages/**/*.{js,ts,jsx,tsx}", "./components/**/*.{js,ts,jsx,tsx}"],
  theme: { extend: {} },
  plugins: [],
}
EOF

cat > "$ROOT/.gitignore" <<'EOF'
node_modules
.env
.env.local
.next
dist
coverage
.DS_Store
EOF

cat > "$ROOT/.env.example" <<'EOF'
DATABASE_URL=postgresql://user:password@localhost:5432/efras_toko?schema=public
NEXTAUTH_SECRET=change-this
STRIPE_SECRET_KEY=
EOF

cat > "$ROOT/CONTRIBUTING.md" <<'EOF'
# Contributing

Thanks for wanting to contribute. Please open issues or PRs. Follow the existing code style and add tests for new features.
EOF

cat > "$ROOT/ISSUE_TEMPLATE.md" <<'EOF'
---
name: Bug report
about: Create a report to help us improve
---
EOF

cat > "$ROOT/PR_TEMPLATE.md" <<'EOF'
---
name: Pull request
about: Describe your changes
---
EOF

cat > "$ROOT/prisma/schema.prisma" <<'EOF'
generator client {
  provider = "prisma-client-js"
}

datasource db {
  provider = "postgresql"
  url      = env("DATABASE_URL")
}

model User {
  id        String   @id @default(cuid())
  name      String?
  email     String   @unique
  image     String?
  createdAt DateTime @default(now())
}

model Product {
  id          String   @id @default(cuid())
  name        String
  slug        String   @unique
  description String?
  priceCents  Int
  image       String?
  createdAt   DateTime @default(now())
}
EOF

cat > "$ROOT/prisma/seed.ts" <<'EOF'
import { PrismaClient } from '@prisma/client'
const prisma = new PrismaClient()

async function main(){
  await prisma.product.createMany({
    data: [
      { name: 'Kopi Arabica', slug: 'kopi-arabica', description: 'Kopi premium', priceCents: 50000, image: '/images/kopi.jpg' },
      { name: 'Teh Hijau', slug: 'teh-hijau', description: 'Teh sehat', priceCents: 30000, image: '/images/teh.jpg' }
    ],
    skipDuplicates: true
  })
}

main().catch(e => { console.error(e); process.exit(1) }).finally(() => prisma.$disconnect())
EOF

cat > "$ROOT/lib/prisma.ts" <<'EOF'
import { PrismaClient } from '@prisma/client'

declare global {
  // allow global prisma during dev to avoid multiple instances
  var prisma: PrismaClient | undefined
}

const prisma = global.prisma || new PrismaClient()
if (process.env.NODE_ENV !== 'production') global.prisma = prisma

export default prisma
EOF

cat > "$ROOT/pages/_app.tsx" <<'EOF'
import '../styles/globals.css'
import type { AppProps } from 'next/app'

export default function App({ Component, pageProps }: AppProps) {
  return <Component {...pageProps} />
}
EOF

cat > "$ROOT/pages/index.tsx" <<'EOF'
import Link from 'next/link'

export default function Home(){
  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold">Efras Toko</h1>
      <p className="mt-4">Selamat datang di toko contoh.</p>
      <Link href="/products"><a className="text-blue-600">Lihat Produk</a></Link>
    </main>
  )
}
EOF

cat > "$ROOT/pages/products/index.tsx" <<'EOF'
import { GetServerSideProps } from 'next'
import prismaClient from '../../lib/prisma'
import Link from 'next/link'

export default function Products({ products }: any){
  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-xl font-bold">Produk</h1>
      <ul>
        {products.map((p: any) => (
          <li key={p.id}><Link href={`/products/${p.slug}`}><a>{p.name} - Rp{(p.priceCents/100).toLocaleString()}</a></Link></li>
        ))}
      </ul>
    </main>
  )
}

export const getServerSideProps: GetServerSideProps = async () => {
  const products = await prismaClient.product.findMany()
  return { props: { products } }
}
EOF

cat > "$ROOT/pages/products/[slug].tsx" <<'EOF'
import { GetServerSideProps } from 'next'
import prismaClient from '../../lib/prisma'

export default function ProductPage({ product }: any){
  if(!product) return <div>Produk tidak ditemukan</div>
  return (
    <main className="max-w-4xl mx-auto p-6">
      <h1 className="text-2xl font-bold">{product.name}</h1>
      <p className="mt-2">{product.description}</p>
      <p className="mt-4 font-semibold">Rp{(product.priceCents/100).toLocaleString()}</p>
    </main>
  )
}

export const getServerSideProps: GetServerSideProps = async (ctx) => {
  const slug = ctx.params?.slug as string
  const product = await prismaClient.product.findUnique({ where: { slug } })
  return { props: { product } }
}
EOF

cat > "$ROOT/pages/api/products.ts" <<'EOF'
import type { NextApiRequest, NextApiResponse } from 'next'
import prisma from '../../lib/prisma'

export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if(req.method === 'GET'){
    const products = await prisma.product.findMany()
    return res.status(200).json(products)
  }
  if(req.method === 'POST'){
    // admin create - placeholder, secure this route
    const { name, slug, priceCents, description, image } = req.body
    const product = await prisma.product.create({ data: { name, slug, priceCents, description, image } })
    return res.status(201).json(product)
  }
  res.setHeader('Allow', ['GET','POST'])
  res.status(405).end(`Method ${req.method} Not Allowed`)
}
EOF

cat > "$ROOT/pages/api/checkout.ts" <<'EOF'
import type { NextApiRequest, NextApiResponse } from 'next'
// Stripe logic placeholder
export default async function handler(req: NextApiRequest, res: NextApiResponse){
  if(req.method === 'POST'){
    // create Stripe Checkout Session here
    return res.status(200).json({ url: '/success' })
  }
  res.status(405).end()
}
EOF

cat > "$ROOT/pages/api/auth/[...nextauth].ts" <<'EOF'
import NextAuth from 'next-auth'
import Providers from 'next-auth/providers'

export default NextAuth({
  providers: [],
  secret: process.env.NEXTAUTH_SECRET
})
EOF

cat > "$ROOT/styles/globals.css" <<'EOF'
@tailwind base;
@tailwind components;
@tailwind utilities;
EOF

cat > "$ROOT/Dockerfile" <<'EOF'
# Node 18
FROM node:18-alpine AS base
WORKDIR /app
COPY package*.json ./
RUN npm ci --omit=dev
COPY . .
RUN npm run build

CMD ["npm","start"]
EOF

cat > "$ROOT/.github/workflows/ci.yml" <<'EOF'
name: CI
on: [push, pull_request]
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: pnpm/action-setup@v2
        with:
          node-version: 18
      - run: npm ci
      - run: npm run build
EOF

# Create ZIP
ZIPFILE="efras-toko.zip"
if command -v zip >/dev/null 2>&1; then
  rm -f "$ZIPFILE"
  zip -r "$ZIPFILE" "$ROOT" >/dev/null
  echo "Created $ZIPFILE in $(pwd)"
else
  echo "zip command not found. Created project folder '$ROOT' but couldn't create ZIP."
  echo "To create ZIP, install zip (e.g. apt-get install zip) and run:"
  echo "  zip -r $ZIPFILE $ROOT"
fi

echo "Done."
EOF