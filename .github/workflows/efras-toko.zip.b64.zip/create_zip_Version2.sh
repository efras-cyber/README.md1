#!/usr/bin/env bash
# Usage: chmod +x create_zip.sh && ./create_zip.sh
set -e
DIR="efras-toko"
rm -rf "$DIR"
mkdir -p "$DIR"

cat > "$DIR/index.html" <<'EOF'
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Efras Toko — Warung Serba Ada</title>
  <meta name="description" content="Efras Toko — Warung serba ada: sembako, minuman, kebutuhan rumah tangga. Belanja online mudah dengan COD, transfer bank, DANA, atau QRIS." />
  <link rel="stylesheet" href="styles.css" />
  <link rel="icon" href="https://source.unsplash.com/32x32/?store" />
  <!-- QRCode lib -->
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" defer></script>
  <script src="script.js" defer></script>
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <div class="brand">
        <a href="index.html" class="brand-link">
          <img src="https://source.unsplash.com/80x80/?shop,stall" alt="Efras Toko" class="logo" />
          <div>
            <h1>Efras Toko</h1>
            <p class="tagline">Warung Serba Ada • Cepat & Terpercaya</p>
          </div>
        </a>
      </div>
      <nav class="main-nav">
        <a href="#home">Beranda</a>
        <a href="#popular">Produk Populer</a>
        <a href="#all-products">Semua Produk</a>
        <a href="#about">Tentang Kami</a>
        <a href="checkout.html" id="cart-link">Keranjang (0)</a>
      </nav>
      <button class="mobile-menu-toggle" aria-label="menu">☰</button>
    </div>
  </header>

  <main>
    <section id="home" class="hero">
      <div class="container hero-inner">
        <div class="hero-text">
          <h2>Selamat datang di Efras Toko</h2>
          <p>Warung serba ada online — sembako, minuman, kebutuhan rumah tangga, dan lainnya. Pengiriman cepat, berbagai opsi pembayaran.</p>
          <p><strong>Alamat:</strong> Jl. Contoh No.123, Kota Contoh • Buka 08:00 - 20:00</p>
          <div class="cta-row">
            <a href="#all-products" class="btn">Belanja Sekarang</a>
            <a href="#about" class="btn ghost">Tentang Kami</a>
          </div>
        </div>
        <div class="hero-image">
          <img src="https://source.unsplash.com/900x600/?local-shop,mini-mart,warung" alt="Warung serba ada" />
        </div>
      </div>
    </section>

    <section id="popular" class="section container">
      <h3>Produk Terpopuler</h3>
      <div id="popular-products" class="product-grid"></div>
    </section>

    <section id="all-products" class="section container">
      <div class="section-head">
        <h3>Semua Produk</h3>
        <div class="controls">
          <select id="category-filter">
            <option value="all">Semua Kategori</option>
            <option value="makanan">Makanan</option>
            <option value="minuman">Minuman</option>
            <option value="sembako">Sembako</option>
            <option value="rumah">Perlengkapan Rumah</option>
          </select>
          <input id="search" placeholder="Cari produk..." />
        </div>
      </div>
      <div id="product-list" class="product-grid"></div>
    </section>

    <section id="shipping" class="section container">
      <h3>Jasa Pengiriman & Kurir</h3>
      <div class="shipping-grid">
        <div class="card">
          <img src="https://source.unsplash.com/400x200/?delivery,truck" alt="JNE" />
          <h4>JNE</h4>
          <p>Estimasi 1-3 hari kerja. Lacak paket.</p>
        </div>
        <div class="card">
          <img src="https://source.unsplash.com/400x200/?courier,parcel" alt="SiCepat" />
          <h4>SiCepat</h4>
          <p>Pengiriman cepat, ideal untuk produk kecil.</p>
        </div>
        <div class="card">
          <img src="https://source.unsplash.com/400x200/?motorbike,delivery" alt="Kurir Lokal" />
          <h4>Kurir Lokal</h4>
          <p>Antar hari yang sama (jika area dekat).</p>
        </div>
      </div>
    </section>

    <section id="payments" class="section container">
      <h3>Metode Pembayaran</h3>
      <ul class="payments-list">
        <li><strong>COD:</strong> Bayar saat barang diterima (lakukan konfirmasi alamat).</li>
        <li><strong>Transfer Bank:</strong> BCA 123-456-789 a.n. Efras Toko (contoh).</li>
        <li><strong>DANA:</strong> 0812xxxxxxx (Efras Toko).</li>
        <li><strong>QRIS / QR Kode:</strong> Tersedia saat checkout — pindai & bayar.</li>
      </ul>
      <div class="qrcode-sample">
        <div id="sample-qr"></div>
        <p>Contoh QR demo untuk pembayaran.</p>
      </div>
    </section>

    <section id="about" class="section container about">
      <h3>Tentang Kami</h3>
      <p>Efras Toko hadir untuk memenuhi kebutuhan harian Anda. Kami menyediakan produk berkualitas, pengiriman cepat, dan berbagai metode pembayaran untuk kenyamanan Anda.</p>
      <p><strong>Kontak:</strong> 0812-xxxx-xxxx • <strong>Email:</strong> efras@contoh.com</p>
      <div class="map-placeholder">
        <img src="https://source.unsplash.com/1200x400/?storefront,shop" alt="Lokasi toko Efras" />
      </div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-inner">
      <div>
        <h4>Efras Toko</h4>
        <p>Alamat: Jl. Contoh No.123 — Kota Contoh</p>
        <p>Jam: 08:00 - 20:00 • Telp: 0812-xxxx-xxxx</p>
      </div>
      <div>
        <h4>Ikuti Kami</h4>
        <p>Instagram • Facebook</p>
      </div>
    </div>
  </footer>

  <template id="product-card-tpl">
    <article class="product-card" role="article">
      <img class="product-img" alt="produk" />
      <div class="product-body">
        <h4 class="product-title"></h4>
        <p class="product-price"></p>
        <div class="product-actions">
          <button class="btn view-detail">Lihat</button>
          <button class="btn add-to-cart">Tambah ke Keranjang</button>
        </div>
      </div>
    </article>
  </template>

  <script>
    // generate sample QR on homepage
    document.addEventListener('DOMContentLoaded', function () {
      const qrEl = document.getElementById('sample-qr');
      if (qrEl && window.QRCode) {
        new QRCode(qrEl, { text: "https://efras.biz.id/ pembayaran-demo", width: 140, height: 140 });
      }
    });
  </script>
</body>
</html>
EOF

cat > "$DIR/product.html" <<'EOF'
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Detail Produk — Efras Toko</title>
  <link rel="stylesheet" href="styles.css" />
  <script src="script.js" defer></script>
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <div class="brand">
        <a href="index.html" class="brand-link">
          <img src="https://source.unsplash.com/80x80/?shop" alt="Efras Toko" class="logo" />
          <div>
            <h1>Efras Toko</h1>
          </div>
        </a>
      </div>
      <nav class="main-nav">
        <a href="index.html">Belanja</a>
        <a href="checkout.html" id="cart-link">Keranjang (0)</a>
      </nav>
    </div>
  </header>

  <main class="container">
    <div id="product-detail" class="product-detail"></div>
  </main>

  <footer class="site-footer">
    <div class="container footer-inner">
      <div>Efras Toko — Warung Serba Ada</div>
      <div>Kontak: 0812-xxxx-xxxx</div>
    </div>
  </footer>

  <script>
    // Read ?id=... and render product detail
    document.addEventListener('DOMContentLoaded', () => {
      const params = new URLSearchParams(location.search);
      const id = params.get('id');
      if (!id) {
        document.getElementById('product-detail').innerHTML = '<p>Produk tidak ditemukan. <a href="index.html">Kembali</a></p>';
        return;
      }
      const prod = (window.PRODUCTS || []).find(p=>p.id===id);
      if (!prod) {
        document.getElementById('product-detail').innerHTML = '<p>Produk tidak ditemukan (id:'+id+'). <a href="index.html">Kembali</a></p>';
        return;
      }
      const el = document.getElementById('product-detail');
      el.innerHTML = `
        <div class="detail-grid">
          <div class="detail-image"><img src="${prod.img}" alt="${prod.title}" /></div>
          <div class="detail-body">
            <h2>${prod.title}</h2>
            <p class="product-price">${(new Intl.NumberFormat('id-ID', { style:'currency', currency:'IDR' })).format(prod.price)}</p>
            <p>Kategori: ${prod.category}</p>
            <p>Deskripsi singkat: Produk berkualitas tersedia di Efras Toko.</p>
            <div class="detail-actions">
              <button class="btn add-to-cart" data-id="${prod.id}">Tambah ke Keranjang</button>
              <a href="checkout.html" class="btn ghost">Checkout</a>
            </div>
          </div>
        </div>
      `;
      el.querySelector('.add-to-cart').addEventListener('click', (e)=>{
        addToCart(prod.id);
      });
    });
  </script>
</body>
</html>
EOF

cat > "$DIR/checkout.html" <<'EOF'
<!doctype html>
<html lang="id">
<head>
  <meta charset="utf-8" />
  <meta name="viewport" content="width=device-width,initial-scale=1" />
  <title>Checkout — Efras Toko</title>
  <link rel="stylesheet" href="styles.css" />
  <script src="https://cdnjs.cloudflare.com/ajax/libs/qrcodejs/1.0.0/qrcode.min.js" defer></script>
  <script src="checkout.js" defer></script>
</head>
<body>
  <header class="site-header">
    <div class="container header-inner">
      <div class="brand"><a href="index.html"><img src="https://source.unsplash.com/80x80/?shop" alt="Efras Toko" class="logo" /></a></div>
      <nav class="main-nav">
        <a href="index.html">Belanja</a>
        <a href="checkout.html">Keranjang</a>
      </nav>
    </div>
  </header>

  <main class="container">
    <h2>Keranjang & Checkout</h2>
    <div id="cart-area"></div>

    <section id="checkout-form" class="card" style="margin-top:1rem;">
      <h3>Detail Pengiriman</h3>
      <label>Nama Pembeli<br/><input id="name" placeholder="Nama lengkap" /></label><br />
      <label>Alamat Lengkap<br/><textarea id="address" placeholder="Alamat, kecamatan, kota, kode pos"></textarea></label><br/>
      <label>Nomor Telepon<br/><input id="phone" placeholder="08xx" /></label>

      <h3>Pilih Jasa Pengiriman</h3>
      <select id="shipping-select">
        <option value="jne" data-cost="15000">JNE — Rp 15.000</option>
        <option value="sicepat" data-cost="12000">SiCepat — Rp 12.000</option>
        <option value="jnt" data-cost="13000">J&T — Rp 13.000</option>
        <option value="cod" data-cost="0">Kurir Lokal (COD)</option>
      </select>

      <h3>Pilih Metode Pembayaran</h3>
      <label><input type="radio" name="pay" value="cod" checked /> COD</label><br/>
      <label><input type="radio" name="pay" value="bank" /> Transfer Bank</label><br/>
      <label><input type="radio" name="pay" value="dana" /> DANA</label><br/>
      <label><input type="radio" name="pay" value="qris" /> QRIS / QR</label>

      <div style="margin-top:1rem;">
        <button id="place-order" class="btn">Buat Pesanan</button>
      </div>
    </section>

    <section id="order-summary" class="card" style="margin-top:1rem; display:none;">
      <h3>Ringkasan Pesanan</h3>
      <div id="summary-content"></div>
      <div id="payment-instructions"></div>
      <div id="qr-target" style="margin-top:1rem;"></div>
    </section>
  </main>

  <footer class="site-footer">
    <div class="container footer-inner">
      <div>Efras Toko — Warung Serba Ada</div>
      <div>Kontak: 0812-xxxx-xxxx</div>
    </div>
  </footer>
</body>
</html>
EOF

cat > "$DIR/styles.css" <<'EOF'
:root{
  --brand:#1f6feb;
  --muted:#666;
  --card:#fff;
  --bg:#f5f6f8;
  --accent:#2dbe60;
}
*{box-sizing:border-box}
body{font-family:Inter, system-ui, -apple-system, "Segoe UI", Roboto, "Helvetica Neue", Arial;margin:0;background:var(--bg);color:#111;line-height:1.45}
.container{max-width:1100px;margin:0 auto;padding:1rem}
.site-header{background:#fff;border-bottom:1px solid #e6e6e6;position:sticky;top:0;z-index:20}
.header-inner{display:flex;align-items:center;justify-content:space-between;padding:0.6rem 0}
.brand-link{display:flex;gap:0.8rem;align-items:center;text-decoration:none;color:inherit}
.brand h1{margin:0;font-size:1.1rem}
.brand .tagline{margin:0;font-size:0.82rem;color:var(--muted)}
.logo{border-radius:8px;width:56px;height:56px;object-fit:cover}
.main-nav a{margin-left:1rem;color:var(--muted);text-decoration:none}
.main-nav a:hover{color:var(--brand)}
.mobile-menu-toggle{display:none;background:transparent;border:0;font-size:1.3rem}

/* Hero */
.hero{padding:2rem 0;background:linear-gradient(90deg, #fff 0%, #fbfdff 100%)}
.hero-inner{display:flex;gap:2rem;align-items:center}
.hero-text{flex:1}
.hero-text h2{margin:0 0 0.5rem 0}
.hero-text p{margin:0.3rem 0;color:var(--muted)}
.hero-image img{width:460px;max-width:100%;border-radius:8px;box-shadow:0 6px 20px rgba(20,20,30,0.06)}
.cta-row{margin-top:1rem;display:flex;gap:0.5rem}

/* Sections */
.section{padding:2rem 0}
.section-head{display:flex;justify-content:space-between;align-items:center;margin-bottom:1rem;gap:1rem}
.controls{display:flex;gap:0.5rem;align-items:center}
.controls select, .controls input{padding:0.6rem;border-radius:6px;border:1px solid #ddd}

/* Products */
.product-grid{display:grid;grid-template-columns:repeat(auto-fill,minmax(220px,1fr));gap:1rem}
.product-card{background:var(--card);border-radius:8px;padding:0.6rem;box-shadow:0 4px 12px rgba(20,20,30,0.04);display:flex;flex-direction:column;height:100%}
.product-img{height:150px;width:100%;object-fit:cover;border-radius:6px}
.product-body{padding:0.5rem 0;display:flex;flex-direction:column;flex:1}
.product-title{margin:0;font-size:1rem}
.product-price{margin-top:auto;font-weight:700;color:var(--brand)}
.product-actions{margin-top:0.5rem;display:flex;gap:0.5rem}
.btn{background:var(--brand);color:#fff;padding:0.56rem 0.85rem;border-radius:6px;text-decoration:none;display:inline-block;border:0;cursor:pointer}
.btn.ghost{background:transparent;color:var(--brand);border:1px solid var(--brand)}
.btn.add-to-cart{background:var(--accent)}
.card{background:#fff;padding:1rem;border-radius:8px;box-shadow:0 6px 18px rgba(20,20,30,0.04)}
.shipping-grid{display:grid;grid-template-columns:repeat(auto-fit,minmax(220px,1fr));gap:1rem}
.payments-list{list-style:disc;padding-left:1.2rem;color:var(--muted)}
.qrcode-sample{margin-top:1rem}

/* Detail */
.detail-grid{display:grid;grid-template-columns:1fr 1fr;gap:1rem}
.detail-image img{width:100%;border-radius:8px}
.detail-actions{display:flex;gap:0.6rem;margin-top:1rem}

/* footer */
.site-footer{background:#0b1220;color:#fff;padding:1.2rem 0;margin-top:2rem}
.footer-inner{display:flex;justify-content:space-between;gap:1rem}

/* responsive */
@media(max-width:900px){
  .hero-inner{flex-direction:column}
  .main-nav{display:none}
  .mobile-menu-toggle{display:block}
  .detail-grid{grid-template-columns:1fr}
  .footer-inner{flex-direction:column}
}
EOF

cat > "$DIR/script.js" <<'EOF'
// PRODUCTS dataset
const PRODUCTS = [
  {"id":"p1","title":"Beras 5kg","price":65000,"category":"sembako","img":"https://source.unsplash.com/400x300/?rice,beras"},
  {"id":"p2","title":"Minyak Goreng 2L","price":27000,"category":"sembako","img":"https://source.unsplash.com/400x300/?cooking-oil"},
  {"id":"p3","title":"Kopi Instan 200g","price":35000,"category":"minuman","img":"https://source.unsplash.com/400x300/?coffee"},
  {"id":"p4","title":"Air Minum 600ml (24 pcs)","price":45000,"category":"minuman","img":"https://source.unsplash.com/400x300/?water-bottle"},
  {"id":"p5","title":"Sabun Cuci Piring","price":12000,"category":"rumah","img":"https://source.unsplash.com/400x300/?dish-soap"},
  {"id":"p6","title":"Snack Keripik 150g","price":8000,"category":"makanan","img":"https://source.unsplash.com/400x300/?chips,snack"},
  {"id":"p7","title":"Telur Ayam 1 lusin","price":24000,"category":"sembako","img":"https://source.unsplash.com/400x300/?eggs"},
  {"id":"p8","title":"Susu UHT 1L","price":18000,"category":"minuman","img":"https://source.unsplash.com/400x300/?milk"},
  {"id":"p9","title":"Bumbu Masak Komplit","price":15000,"category":"makanan","img":"https://source.unsplash.com/400x300/?spices"},
  {"id":"p10","title":"Tissue Gulung 3pcs","price":12000,"category":"rumah","img":"https://source.unsplash.com/400x300/?tissue"}
];

// Cart storage
const CART_KEY = 'efras_cart_v1';
function getCart(){ try { return JSON.parse(localStorage.getItem(CART_KEY))||{} } catch(e){ return {} } }
function saveCart(cart){ localStorage.setItem(CART_KEY, JSON.stringify(cart)); updateCartCount(); }
function updateCartCount(){
  const cart = getCart();
  const count = Object.values(cart).reduce((s,i)=>s+i.qty,0);
  const cartLink = document.getElementById('cart-link');
  if (cartLink) cartLink.textContent = `Keranjang (${count})`;
}

// Render products on page
function renderProducts(listEl, products){
  const tpl = document.getElementById('product-card-tpl');
  listEl.innerHTML = '';
  products.forEach(p=>{
    const node = tpl.content.cloneNode(true);
    const card = node.querySelector('.product-card');
    card.querySelector('.product-img').src = p.img;
    card.querySelector('.product-img').alt = p.title;
    card.querySelector('.product-title').textContent = p.title;
    card.querySelector('.product-price').textContent = formatRp(p.price);
    const btnAdd = card.querySelector('.add-to-cart');
    const btnView = card.querySelector('.view-detail');
    btnAdd.addEventListener('click', ()=> addToCart(p.id));
    btnView.addEventListener('click', ()=> {
      location.href = `product.html?id=${encodeURIComponent(p.id)}`;
    });
    listEl.appendChild(node);
  });
}
function formatRp(n){ return 'Rp ' + n.toLocaleString('id-ID') }

function addToCart(productId){
  const cart = getCart();
  cart[productId] = cart[productId] || { id: productId, qty: 0 };
  cart[productId].qty += 1;
  saveCart(cart);
  // quick feedback
  const previous = document.activeElement;
  alert('Produk ditambahkan ke keranjang');
  if (previous && typeof previous.blur === 'function') previous.blur();
}

// Filters and initialisation
document.addEventListener('DOMContentLoaded', ()=>{
  const popularEl = document.getElementById('popular-products');
  const allEl = document.getElementById('product-list');
  const filter = document.getElementById('category-filter');
  const search = document.getElementById('search');

  if (popularEl) renderProducts(popularEl, PRODUCTS.slice(0,4));
  if (allEl) renderProducts(allEl, PRODUCTS);

  if (filter) filter.addEventListener('change', applyFilters);
  if (search) search.addEventListener('input', applyFilters);

  updateCartCount();

  // mobile menu toggle (basic)
  const menuToggle = document.querySelector('.mobile-menu-toggle');
  const nav = document.querySelector('.main-nav');
  if (menuToggle){
    menuToggle.addEventListener('click', ()=> {
      if (nav.style.display === 'block') nav.style.display = '';
      else nav.style.display = 'block';
    });
  }
});

function applyFilters(){
  const cat = document.getElementById('category-filter').value;
  const q = document.getElementById('search').value.trim().toLowerCase();
  const allEl = document.getElementById('product-list');
  if (!allEl) return;
  let filtered = PRODUCTS.filter(p => (cat==='all' || p.category===cat));
  if (q) filtered = filtered.filter(p => p.title.toLowerCase().includes(q));
  renderProducts(allEl, filtered);
}
EOF

cat > "$DIR/checkout.js" <<'EOF'
// Checkout logic: reads cart from localStorage, allow shipping/payment options, simulate order
const CART_KEY = 'efras_cart_v1';
function loadCart(){ try { return JSON.parse(localStorage.getItem(CART_KEY))||{} } catch(e){ return {} } }
function getProductById(id){
  return (window.PRODUCTS || []).find(p=>p.id===id) || { id, title: id, price:0, img:'https://source.unsplash.com/400x300/?product' };
}
function formatRp(n){ return 'Rp ' + n.toLocaleString('id-ID') }

document.addEventListener('DOMContentLoaded', ()=>{
  renderCart();
  const placeBtn = document.getElementById('place-order');
  if (placeBtn) placeBtn.addEventListener('click', placeOrder);
});

function renderCart(){
  const cart = loadCart();
  const area = document.getElementById('cart-area');
  area.innerHTML = '';
  const items = Object.values(cart);
  if (!items.length) {
    area.innerHTML = '<p>Keranjang kosong. <a href="index.html">Lanjut belanja</a></p>';
    return;
  }
  const list = document.createElement('div');
  list.className = 'product-grid';
  let subtotal = 0;
  items.forEach(ci=>{
    const prod = getProductById(ci.id);
    subtotal += prod.price * ci.qty;
    const card = document.createElement('div');
    card.className = 'product-card';
    card.innerHTML = `
      <img class="product-img" src="${prod.img}" alt="${prod.title}" />
      <div class="product-body">
        <h4 class="product-title">${prod.title}</h4>
        <p>Jumlah: ${ci.qty}</p>
        <p class="product-price">${formatRp(prod.price)} / pcs</p>
      </div>
    `;
    list.appendChild(card);
  });
  area.appendChild(list);
  const sumCard = document.createElement('div');
  sumCard.className = 'card';
  sumCard.style.marginTop = '1rem';
  sumCard.innerHTML = `<h3>Subtotal: ${formatRp(subtotal)}</h3>`;
  area.appendChild(sumCard);
}

function placeOrder(){
  const name = document.getElementById('name').value.trim();
  const address = document.getElementById('address').value.trim();
  const phone = document.getElementById('phone').value.trim();
  if (!name || !address || !phone) return alert('Isi detail pengiriman lengkap');
  const shippingSel = document.getElementById('shipping-select');
  const shipCost = parseInt(shippingSel.selectedOptions[0].dataset.cost||0,10);
  const payMethod = document.querySelector('input[name="pay"]:checked').value;

  const cart = loadCart();
  const items = Object.values(cart);
  let subtotal = 0;
  const lines = items.map(ci=>{
    const p = getProductById(ci.id);
    subtotal += p.price * ci.qty;
    return `${p.title} x${ci.qty} — ${formatRp(p.price * ci.qty)}`;
  }).join('<br/>');

  const total = subtotal + shipCost;
  // show summary
  document.getElementById('order-summary').style.display = 'block';
  document.getElementById('summary-content').innerHTML = `
    <p><strong>Nama:</strong> ${name}</p>
    <p><strong>Telepon:</strong> ${phone}</p>
    <p><strong>Alamat:</strong> ${address}</p>
    <p><strong>Isi Pesanan:</strong><br/>${lines}</p>
    <p><strong>Ongkir:</strong> ${formatRp(shipCost)}</p>
    <h3>Total: ${formatRp(total)}</h3>
  `;

  const instr = document.getElementById('payment-instructions');
  instr.innerHTML = '';
  const qrTarget = document.getElementById('qr-target');
  qrTarget.innerHTML = '';
  if (payMethod === 'cod'){
    instr.innerHTML = `<p>Pilih COD: Bayar pada saat barang diterima. Pastikan alamat & nomor telepon benar.</p>`;
  } else if (payMethod === 'bank'){
    instr.innerHTML = `<p>Transfer ke: BCA 123-456-789 a.n. Efras Toko<br/>Setelah transfer, kirim bukti pembayaran ke WA 0812-xxxx-xxxx.</p>`;
  } else if (payMethod === 'dana'){
    instr.innerHTML = `<p>Bayar via DANA ke: 0812xxxxxxx (Efras Toko). Jangan lupa konfirmasi bukti pembayaran.</p>`;
  } else if (payMethod === 'qris'){
    instr.innerHTML = `<p>Pindai QR di bawah untuk membayar (QRIS demo).</p>`;
    if (window.QRCode){
      new QRCode(qrTarget, { text: `efras-toko://pembayaran?amount=${total}`, width:200, height:200 });
      const label = document.createElement('p'); label.textContent = 'Scan QR untuk demo pembayaran';
      qrTarget.appendChild(label);
    } else {
      qrTarget.innerHTML = '<p>(QR generator tidak tersedia)</p>';
    }
  }

  // Simulate order id and clear cart
  const orderId = 'ORD' + Date.now();
  instr.innerHTML += `<p style="margin-top:0.6rem"><strong>Order ID:</strong> ${orderId}</p>`;
  localStorage.removeItem(CART_KEY);
  document.getElementById('place-order').disabled = true;
  alert('Pesanan dibuat. ID: ' + orderId + '. Simulasi: pesanan tidak benar-benar dikirim.');
}
EOF

cat > "$DIR/CNAME" <<'EOF'
efras.biz.id
EOF

cat > "$DIR/README.md" <<'EOF'
# Efras Toko — Static Template (Deploy-ready)

Ini paket file statis untuk website e-commerce sederhana "Efras Toko". Termasuk:
- index.html (beranda, produk, kategori, info toko)
- product.html (halaman detail produk)
- checkout.html (keranjang & checkout)
- styles.css, script.js, checkout.js
- CNAME (isi: efras.biz.id) untuk GitHub Pages custom domain

Cara pakai lokal:
1. Simpan semua file ke satu folder.
2. Buka `index.html` pada browser.

Deployment ke domain https://efras.biz.id/
Pilihan A — GitHub Pages (direkomendasikan jika Anda nyaman dengan git):
1. Buat repo baru di GitHub (mis. `efras-toko`), push semua file ke branch `main`.
2. Pastikan file `CNAME` berada di root (sudah disertakan).
3. Di GitHub Repo → Settings → Pages: pilih branch `main` / folder `/ (root)` dan simpan.
4. Atur DNS domain:
   - Jika menggunakan GitHub Pages dengan A-record, tambahkan A records ke IP GitHub Pages:
     - 185.199.108.153
     - 185.199.109.153
     - 185.199.110.153
     - 185.199.111.153
   - Alternatif: tambahkan CNAME record: `efras.biz.id` → `<your-github-username>.github.io`
5. Tunggu propagasi DNS (bisa 5–60 menit). GitHub Pages akan melayani `efras.biz.id`.

Pilihan B — Netlify (mudah dan cepat):
1. Buka https://app.netlify.com/ → drag & drop folder hasil build ke dashboard (Static Sites).
2. Di Site Settings → Domain management → add custom domain `efras.biz.id`.
3. Netlify akan memberi instruksi DNS (biasanya CNAME atau A records). Ikuti instruksi dan tambahkan record di panel domain registrar.
4. Setelah DNS terpropagasi, domain aktif.

Pilihan C — Hosting (FTP / cPanel):
1. Upload semua file ke folder publik (biasanya `public_html`) via FTP atau File Manager.
2. Pastikan domain diarahkan ke hosting (A record ke IP server).
3. Setelah upload, buka https://efras.biz.id/

Catatan penting:
- Template ini hanya front-end (demo). Untuk menerima pembayaran nyata Anda harus:
  - Integrasikan gateway pembayaran resmi (Midtrans, Xendit, dsb.) dan server backend untuk verifikasi.
  - Tambahkan sistem order / database untuk menyimpan pesanan.
  - Pastikan HTTPS aktif (Let's Encrypt atau penyedia hosting) sebelum menerima data pelanggan.
- Gambar saat ini menggunakan Unsplash (placeholder). Ganti gambar dengan milik Anda di folder / URL jika diperlukan.
- Untuk kustom (logo, rekening bank, nomor WA, alamat), ubah pada `index.html` / `checkout.js`.

Butuh saya bantu:
- Membuat repo GitHub & push file (saya bisa buatkan langkah perintah git).
- Mengemas file menjadi ZIP untuk diunduh.
- Membuat instruksi DNS spesifik untuk provider domain Anda (sebutkan registrar jika mau).
- Mengubah konten (logo, nomor rekening, alamat) — kirim detail yang ingin dimasukkan.
EOF

# create zip
ZIPNAME="efras-toko.zip"
rm -f "$ZIPNAME"
(cd "$DIR" && zip -r "../$ZIPNAME" .)
echo "Created $ZIPNAME in $(pwd)"